#include "workers_management.h"

#ifndef _WORKERS_COMPUTE_H_
#define _WORKERS_COMPUTE_H_

void* work(void* arg);

#endif
